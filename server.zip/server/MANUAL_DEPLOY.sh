#!/bin/bash

# Manual Deployment Script
# Use this when files are not on GitHub yet

set -e

echo "🚀 Manual Deployment to VPS"
echo "============================"
echo ""

# Configuration
VPS_HOST="72.61.87.54"
VPS_USER="root"
LOCAL_PATH="/Users/romanpochtman/Developer/esimmain/server"
REMOTE_PATH="/opt/esim-service"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_info() {
    echo -e "${YELLOW}ℹ $1${NC}"
}

# Check if we're in the right directory
if [ ! -f "docker-compose.yml" ]; then
    print_error "Please run this script from the server directory"
    exit 1
fi

print_info "Step 1: Compressing files..."
cd ..
tar -czf server-deploy.tar.gz \
    --exclude='server/api/node_modules' \
    --exclude='server/dashboard/node_modules' \
    --exclude='server/logs' \
    --exclude='server/.env' \
    server/

print_success "Files compressed"

print_info "Step 2: Uploading to VPS..."
scp server-deploy.tar.gz $VPS_USER@$VPS_HOST:/tmp/

print_success "Files uploaded"

print_info "Step 3: Setting up on VPS..."

ssh $VPS_USER@$VPS_HOST << 'ENDSSH'
    set -e
    
    echo "📦 Extracting files..."
    cd /opt
    
    # Backup existing installation if it exists
    if [ -d "esim-service" ]; then
        echo "Backing up existing installation..."
        mv esim-service esim-service.backup.$(date +%Y%m%d-%H%M%S)
    fi
    
    # Extract new files
    tar -xzf /tmp/server-deploy.tar.gz
    mv server esim-service
    cd esim-service
    
    echo "✓ Files extracted"
    
    # Check if Docker is installed
    if ! command -v docker &> /dev/null; then
        echo "🐳 Installing Docker..."
        
        # Update system
        apt-get update
        apt-get upgrade -y
        
        # Install Docker
        curl -fsSL https://get.docker.com -o get-docker.sh
        sh get-docker.sh
        rm get-docker.sh
        
        # Install Docker Compose
        curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
        chmod +x /usr/local/bin/docker-compose
        
        # Start Docker
        systemctl enable docker
        systemctl start docker
        
        echo "✓ Docker installed"
    else
        echo "✓ Docker already installed"
    fi
    
    # Check if .env exists
    if [ ! -f ".env" ]; then
        echo ""
        echo "⚠️  WARNING: .env file not found!"
        echo "You need to create .env file before starting services."
        echo ""
        echo "Run these commands:"
        echo "  cd /opt/esim-service"
        echo "  nano .env"
        echo ""
        echo "Then copy the template below and fill in your credentials."
        echo ""
    else
        echo "✓ .env file found"
    fi
    
    # Clean up
    rm /tmp/server-deploy.tar.gz
    
    echo ""
    echo "✓ Setup complete!"
    echo ""
    echo "Next steps:"
    echo "1. Create .env file if not exists: nano /opt/esim-service/.env"
    echo "2. Start services: cd /opt/esim-service && docker-compose up -d --build"
    echo "3. Check status: docker-compose ps"
    echo "4. View logs: docker-compose logs -f"
    echo ""
ENDSSH

print_success "Deployment complete!"

# Clean up local tar file
rm server-deploy.tar.gz

echo ""
print_info "VPS Setup Complete!"
echo ""
echo "Next steps on VPS:"
echo "  ssh root@$VPS_HOST"
echo "  cd /opt/esim-service"
echo ""
echo "If .env doesn't exist, create it:"
echo "  nano .env"
echo ""
echo "Then start services:"
echo "  docker-compose up -d --build"
echo ""
echo "Access your services:"
echo "  API: http://$VPS_HOST/api/"
echo "  Dashboard: http://$VPS_HOST/dashboard"
echo "  Health: http://$VPS_HOST/health"
echo ""

