# 🚀 Quick Reference Card

## 📞 VPS Access
```bash
ssh root@72.61.87.54
# Password: VWJetta2014Asd))
```

## 🔗 Service URLs
- **API**: http://72.61.87.54/api/
- **Dashboard**: http://72.61.87.54/dashboard
- **Health**: http://72.61.87.54/health

## 🐳 Docker Commands

### Start Services
```bash
cd /opt/esim-service
docker-compose up -d --build
```

### Stop Services
```bash
docker-compose down
```

### View Logs
```bash
docker-compose logs -f              # All services
docker-compose logs -f api          # API only
docker-compose logs -f dashboard    # Dashboard only
```

### Check Status
```bash
docker-compose ps
```

### Restart Services
```bash
docker-compose restart              # All services
docker-compose restart api          # API only
```

### Update Services
```bash
docker-compose pull
docker-compose up -d --build
```

## 🔍 Health Checks

### Quick Health Check
```bash
curl http://72.61.87.54/health
```

### Detailed Health Check
```bash
curl http://72.61.87.54/api/health | jq
```

### Check All Services
```bash
# API
curl http://72.61.87.54/api/health

# Dashboard (requires auth)
curl -u admin:password http://72.61.87.54/dashboard/api/health

# Redis
docker exec esim-redis redis-cli ping
```

## 🧪 Testing

### Run All Tests
```bash
cd /opt/esim-service
./test-api.sh http://72.61.87.54
```

### Test Individual Endpoints
```bash
# Health
curl http://72.61.87.54/api/health

# Create Payment
curl -X POST http://72.61.87.54/api/payment/stripe/create \
  -H "Content-Type: application/json" \
  -d '{"amount": 29.99, "currency": "USD"}'

# Send OTP
curl -X POST http://72.61.87.54/api/otp/send \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber": "+1234567890"}'

# Send Email
curl -X POST http://72.61.87.54/api/email/send \
  -H "Content-Type: application/json" \
  -d '{"to": "test@example.com", "subject": "Test", "html": "<h1>Test</h1>"}'

# Get Transactions
curl http://72.61.87.54/api/transactions
```

## 📊 Monitoring

### View Dashboard
```
URL: http://72.61.87.54/dashboard
Username: [from .env DASHBOARD_USERNAME]
Password: [from .env DASHBOARD_PASSWORD]
```

### Check Logs
```bash
# Application logs
tail -f /opt/esim-service/logs/combined-$(date +%Y-%m-%d).log

# Error logs only
tail -f /opt/esim-service/logs/error-$(date +%Y-%m-%d).log

# Nginx logs
tail -f /opt/esim-service/logs/nginx/access.log
tail -f /opt/esim-service/logs/nginx/error.log
```

### System Resources
```bash
# Disk space
df -h

# Memory usage
free -h

# Docker stats
docker stats

# Container health
docker ps
```

## 🔧 Troubleshooting

### Service Won't Start
```bash
# Check logs
docker-compose logs api

# Rebuild
docker-compose down
docker-compose up -d --build --force-recreate

# Check config
docker-compose config
```

### Database Connection Issues
```bash
# Test Supabase connection
curl -H "apikey: YOUR_KEY" https://YOUR_PROJECT.supabase.co/rest/v1/

# Check environment
docker-compose exec api env | grep SUPABASE
```

### Payment Issues
```bash
# Check Stripe webhook
curl -X POST http://72.61.87.54/api/payment/stripe/webhook \
  -H "stripe-signature: test"

# View payment logs
docker-compose logs api | grep payment
```

### Email Issues
```bash
# Test SMTP connection
docker-compose exec api node -e "
const nodemailer = require('nodemailer');
const transport = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASSWORD
  }
});
transport.verify().then(console.log).catch(console.error);
"
```

## 🔐 Security

### Update Firewall
```bash
ufw status
ufw allow 80/tcp
ufw allow 443/tcp
ufw reload
```

### Check Fail2ban
```bash
fail2ban-client status
```

### SSL Certificate (Production)
```bash
# Install certbot
apt-get install certbot python3-certbot-nginx

# Get certificate
certbot certonly --standalone -d your-domain.com

# Renew certificate
certbot renew --dry-run
```

## 📝 Configuration

### Edit Environment
```bash
nano /opt/esim-service/.env
docker-compose restart
```

### Update Nginx Config
```bash
nano /opt/esim-service/nginx/nginx.conf
docker-compose restart nginx
```

## 🔄 Backup & Restore

### Backup Database (Supabase)
- Use Supabase dashboard
- Or use Supabase CLI
- Automatic backups enabled

### Backup Logs
```bash
tar -czf logs-backup-$(date +%Y%m%d).tar.gz /opt/esim-service/logs/
```

### Backup Configuration
```bash
tar -czf config-backup-$(date +%Y%m%d).tar.gz /opt/esim-service/.env /opt/esim-service/nginx/
```

## 📞 API Keys & Credentials

### Supabase
- URL: [Check .env]
- Service Key: [Check .env]
- Dashboard: https://app.supabase.com

### Stripe
- Secret Key: [Check .env]
- Webhook Secret: [Check .env]
- Dashboard: https://dashboard.stripe.com

### Twilio
- Account SID: [Check .env]
- Auth Token: [Check .env]
- Console: https://console.twilio.com

### Hostinger
- API Key: hrJLLYoLbcdLvTcnBlhZdfyJqI8GUhmeU8zipQfPfdc35905
- Panel: https://hpanel.hostinger.com

## 🆘 Emergency Commands

### Stop Everything
```bash
docker-compose down
```

### Restart Everything
```bash
docker-compose restart
```

### Clean Everything (DANGER!)
```bash
docker-compose down -v  # Removes volumes!
```

### View All Logs
```bash
docker-compose logs --tail=100 -f
```

### Check Disk Space
```bash
df -h
du -sh /opt/esim-service/*
```

## 📊 Common Queries

### Get Recent Transactions
```bash
curl http://72.61.87.54/api/transactions?limit=10
```

### Get Failed Transactions
```bash
curl http://72.61.87.54/api/transactions?status=failed
```

### Get Email Logs
```bash
curl http://72.61.87.54/api/email/logs?limit=10
```

### Check Service Health
```bash
curl http://72.61.87.54/api/health | jq '.services'
```

## 🎯 Performance

### Check Response Times
```bash
curl -w "@-" -o /dev/null -s http://72.61.87.54/api/health << 'EOF'
    time_namelookup:  %{time_namelookup}\n
       time_connect:  %{time_connect}\n
    time_appconnect:  %{time_appconnect}\n
      time_redirect:  %{time_redirect}\n
   time_pretransfer:  %{time_pretransfer}\n
 time_starttransfer:  %{time_starttransfer}\n
                    ----------\n
         time_total:  %{time_total}\n
EOF
```

### Monitor Redis
```bash
docker exec esim-redis redis-cli INFO stats
```

### Check Rate Limiting
```bash
docker exec esim-redis redis-cli KEYS "rl:*"
```

## 📱 Quick Scripts

### Restart All Services
```bash
cd /opt/esim-service && docker-compose restart && docker-compose ps
```

### View Errors Only
```bash
docker-compose logs | grep -i error
```

### Clean Old Logs
```bash
find /opt/esim-service/logs -name "*.log" -mtime +14 -delete
```

### Check All Health
```bash
echo "=== System Health ===" && \
curl -s http://72.61.87.54/health && \
echo -e "\n=== API Health ===" && \
curl -s http://72.61.87.54/api/health | jq && \
echo -e "\n=== Docker Status ===" && \
docker-compose ps
```

---

**Keep this file handy for quick reference!**

Print it out or bookmark it for easy access during operations.

