const Stripe = require('stripe');
const paypal = require('@paypal/checkout-server-sdk');
const supabase = require('../config/supabase');
const logger = require('../utils/logger');

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// PayPal Configuration
const paypalEnvironment = process.env.PAYPAL_MODE === 'live'
  ? new paypal.core.LiveEnvironment(process.env.PAYPAL_CLIENT_ID, process.env.PAYPAL_CLIENT_SECRET)
  : new paypal.core.SandboxEnvironment(process.env.PAYPAL_CLIENT_ID, process.env.PAYPAL_CLIENT_SECRET);

const paypalClient = new paypal.core.PayPalHttpClient(paypalEnvironment);

class PaymentService {
  // Stripe Payment Intent
  async createStripePayment(amount, currency, metadata) {
    try {
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: currency || 'usd',
        metadata,
        automatic_payment_methods: {
          enabled: true,
        },
      });

      // Log transaction to Supabase
      await this.logTransaction({
        payment_id: paymentIntent.id,
        provider: 'stripe',
        amount,
        currency,
        status: 'pending',
        metadata
      });

      logger.info('Stripe payment created', { paymentId: paymentIntent.id });

      return {
        success: true,
        paymentId: paymentIntent.id,
        clientSecret: paymentIntent.client_secret,
        provider: 'stripe'
      };
    } catch (error) {
      logger.error('Stripe payment error', error);
      throw error;
    }
  }

  // PayPal Order
  async createPayPalOrder(amount, currency, metadata) {
    try {
      const request = new paypal.orders.OrdersCreateRequest();
      request.prefer("return=representation");
      request.requestBody({
        intent: 'CAPTURE',
        purchase_units: [{
          amount: {
            currency_code: currency || 'USD',
            value: amount.toFixed(2)
          },
          description: metadata.description || 'eSIM Purchase'
        }]
      });

      const order = await paypalClient.execute(request);

      // Log transaction to Supabase
      await this.logTransaction({
        payment_id: order.result.id,
        provider: 'paypal',
        amount,
        currency,
        status: 'pending',
        metadata
      });

      logger.info('PayPal order created', { orderId: order.result.id });

      return {
        success: true,
        orderId: order.result.id,
        provider: 'paypal'
      };
    } catch (error) {
      logger.error('PayPal order error', error);
      throw error;
    }
  }

  // Capture PayPal Payment
  async capturePayPalPayment(orderId) {
    try {
      const request = new paypal.orders.OrdersCaptureRequest(orderId);
      const capture = await paypalClient.execute(request);

      // Update transaction in Supabase
      await this.updateTransaction(orderId, {
        status: 'completed',
        captured_at: new Date().toISOString()
      });

      logger.info('PayPal payment captured', { orderId });

      return {
        success: true,
        captureId: capture.result.id,
        status: capture.result.status
      };
    } catch (error) {
      logger.error('PayPal capture error', error);
      throw error;
    }
  }

  // Verify Stripe Webhook
  async verifyStripeWebhook(payload, signature) {
    try {
      const event = stripe.webhooks.constructEvent(
        payload,
        signature,
        process.env.STRIPE_WEBHOOK_SECRET
      );

      // Handle different event types
      switch (event.type) {
        case 'payment_intent.succeeded':
          await this.updateTransaction(event.data.object.id, {
            status: 'completed',
            completed_at: new Date().toISOString()
          });
          break;
        case 'payment_intent.payment_failed':
          await this.updateTransaction(event.data.object.id, {
            status: 'failed',
            failed_at: new Date().toISOString()
          });
          break;
      }

      return { success: true, event };
    } catch (error) {
      logger.error('Stripe webhook verification error', error);
      throw error;
    }
  }

  // Log transaction to Supabase
  async logTransaction(data) {
    try {
      const { data: transaction, error } = await supabase
        .from('transactions')
        .insert([{
          ...data,
          created_at: new Date().toISOString()
        }])
        .select()
        .single();

      if (error) throw error;

      return transaction;
    } catch (error) {
      logger.error('Transaction logging error', error);
      throw error;
    }
  }

  // Update transaction in Supabase
  async updateTransaction(paymentId, updates) {
    try {
      const { data, error } = await supabase
        .from('transactions')
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('payment_id', paymentId)
        .select()
        .single();

      if (error) throw error;

      return data;
    } catch (error) {
      logger.error('Transaction update error', error);
      throw error;
    }
  }

  // Get transaction by ID
  async getTransaction(paymentId) {
    try {
      const { data, error } = await supabase
        .from('transactions')
        .select('*')
        .eq('payment_id', paymentId)
        .single();

      if (error) throw error;

      return data;
    } catch (error) {
      logger.error('Get transaction error', error);
      throw error;
    }
  }

  // Get all transactions with pagination
  async getTransactions(page = 1, limit = 50, filters = {}) {
    try {
      let query = supabase
        .from('transactions')
        .select('*', { count: 'exact' })
        .order('created_at', { ascending: false })
        .range((page - 1) * limit, page * limit - 1);

      if (filters.status) {
        query = query.eq('status', filters.status);
      }

      if (filters.provider) {
        query = query.eq('provider', filters.provider);
      }

      const { data, error, count } = await query;

      if (error) throw error;

      return {
        transactions: data,
        total: count,
        page,
        limit,
        totalPages: Math.ceil(count / limit)
      };
    } catch (error) {
      logger.error('Get transactions error', error);
      throw error;
    }
  }
}

module.exports = new PaymentService();

