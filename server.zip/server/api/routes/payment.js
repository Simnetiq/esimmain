const express = require('express');
const router = express.Router();
const paymentService = require('../services/paymentService');
const { validatePayment } = require('../middleware/validation');
const logger = require('../utils/logger');

// Create Stripe payment
router.post('/stripe/create', validatePayment, async (req, res, next) => {
  try {
    const { amount, currency, metadata } = req.body;
    const result = await paymentService.createStripePayment(amount, currency, metadata);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

// Create PayPal order
router.post('/paypal/create', validatePayment, async (req, res, next) => {
  try {
    const { amount, currency, metadata } = req.body;
    const result = await paymentService.createPayPalOrder(amount, currency, metadata);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

// Capture PayPal payment
router.post('/paypal/capture/:orderId', async (req, res, next) => {
  try {
    const { orderId } = req.params;
    const result = await paymentService.capturePayPalPayment(orderId);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

// Stripe webhook
router.post('/stripe/webhook', express.raw({ type: 'application/json' }), async (req, res, next) => {
  try {
    const signature = req.headers['stripe-signature'];
    const result = await paymentService.verifyStripeWebhook(req.body, signature);
    res.json({ received: true });
  } catch (error) {
    next(error);
  }
});

// Get transaction by ID
router.get('/transaction/:paymentId', async (req, res, next) => {
  try {
    const { paymentId } = req.params;
    const transaction = await paymentService.getTransaction(paymentId);
    res.json(transaction);
  } catch (error) {
    next(error);
  }
});

module.exports = router;

