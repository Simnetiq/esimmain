# ⚡ Quick Deploy Guide (No GitHub Required)

Since your files aren't on GitHub yet, here's the simplest way to deploy:

## 🚀 Super Simple 3-Step Deployment

### Step 1: Upload Files (From Your Mac)

```bash
# Open Terminal on your Mac
cd /Users/romanpochtman/Developer/esimmain

# Compress the server folder
tar -czf server.tar.gz server/ --exclude='**/node_modules' --exclude='**/logs'

# Upload to VPS
scp server.tar.gz root@72.61.87.54:/opt/
```

**Enter password when prompted:** `VWJetta2014Asd))`

---

### Step 2: Setup VPS (On Server)

```bash
# SSH into VPS
ssh root@72.61.87.54
# Password: VWJetta2014Asd))

# Extract files
cd /opt
tar -xzf server.tar.gz
cd server

# Install Docker (first time only)
apt-get update
apt-get install -y curl

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# Install Docker Compose
curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose

# Verify installation
docker --version
docker-compose --version
```

---

### Step 3: Configure and Start

```bash
# Still on VPS in /opt/server

# Create .env file
nano .env
```

**Paste this template and fill in YOUR values:**

```env
# Supabase (Get from https://app.supabase.com)
SUPABASE_URL=https://xxxxx.supabase.co
SUPABASE_SERVICE_KEY=eyJhbGc...

# Stripe (Get from https://dashboard.stripe.com/apikeys)
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...

# PayPal (Optional - Get from https://developer.paypal.com)
PAYPAL_CLIENT_ID=
PAYPAL_CLIENT_SECRET=
PAYPAL_MODE=sandbox

# Twilio (Get from https://console.twilio.com)
TWILIO_ACCOUNT_SID=ACxxxxx
TWILIO_AUTH_TOKEN=
TWILIO_PHONE_NUMBER=+1234567890

# Email (Gmail or SendGrid)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password

# Dashboard Login
DASHBOARD_USERNAME=admin
DASHBOARD_PASSWORD=ChangeThisPassword123!

# System (Leave as is)
REDIS_URL=redis://redis:6379
APP_URL=http://72.61.87.54
NODE_ENV=production
LOG_LEVEL=info
```

**Save:** Press `Ctrl+X`, then `Y`, then `Enter`

```bash
# Start all services
docker-compose up -d --build

# Wait 30 seconds
sleep 30

# Check status
docker-compose ps

# Test it works
curl http://localhost/health
```

---

## ✅ Verify It's Working

### 1. Check Services
```bash
docker-compose ps
```

You should see all services "Up":
- ✅ esim-api
- ✅ esim-redis  
- ✅ esim-dashboard
- ✅ esim-nginx

### 2. Test Health
```bash
curl http://72.61.87.54/health
curl http://72.61.87.54/api/health
```

### 3. Access Dashboard
Open in browser: **http://72.61.87.54/dashboard**

Login with credentials from your `.env` file.

---

## 🎯 Even Simpler: Use the Automated Script

I created a script that does everything for you:

```bash
# From your Mac
cd /Users/romanpochtman/Developer/esimmain/server
./MANUAL_DEPLOY.sh
```

This will:
1. ✅ Compress files
2. ✅ Upload to VPS
3. ✅ Install Docker
4. ✅ Extract files
5. ✅ Prompt you to create .env

Then you just need to:
- Create `.env` file
- Run `docker-compose up -d --build`

---

## 🆘 Troubleshooting

### "Permission denied" when running script
```bash
chmod +x MANUAL_DEPLOY.sh
./MANUAL_DEPLOY.sh
```

### Services won't start
```bash
# Check logs
docker-compose logs

# Rebuild
docker-compose down
docker-compose up -d --build --force-recreate
```

### Can't connect to VPS
```bash
# Test SSH connection
ssh root@72.61.87.54
# Password: VWJetta2014Asd))
```

### Docker not found
```bash
# Install Docker manually
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# Install Docker Compose
curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose
```

---

## 📋 What You Need Before Starting

### Required Accounts (All have free tiers):
1. **Supabase** - Database (https://supabase.com)
2. **Stripe** - Payments (https://stripe.com)
3. **Twilio** - SMS/OTP (https://twilio.com)
4. **Gmail** - Email (or SendGrid)

### Get These Ready:
- [ ] Supabase URL and Service Key
- [ ] Stripe Secret Key and Webhook Secret
- [ ] Twilio Account SID, Auth Token, Phone Number
- [ ] Email SMTP credentials

---

## 🎉 Success!

Once deployed, you'll have:
- ✅ API running at: http://72.61.87.54/api/
- ✅ Dashboard at: http://72.61.87.54/dashboard
- ✅ Payment processing (Stripe & PayPal)
- ✅ OTP/SMS service (Twilio)
- ✅ Email service (SMTP)
- ✅ Real-time monitoring

**Total time:** ~20 minutes

---

## 🔄 Future Updates

To update your deployment:

```bash
# From your Mac
cd /Users/romanpochtman/Developer/esimmain
tar -czf server.tar.gz server/ --exclude='**/node_modules'
scp server.tar.gz root@72.61.87.54:/opt/

# On VPS
ssh root@72.61.87.54
cd /opt
tar -xzf server.tar.gz
cd server
docker-compose up -d --build
```

Or just run: `./MANUAL_DEPLOY.sh`

