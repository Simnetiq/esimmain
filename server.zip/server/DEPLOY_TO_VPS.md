# 🚀 Deploy to VPS - Simple Guide

## Quick Deployment (3 Steps)

### Step 1: Prepare the Package

```bash
# From your local machine
cd /Users/romanpochtman/Developer/esimmain

# Create compressed package (excludes node_modules)
tar -czf server.tar.gz \
  --exclude='server/api/node_modules' \
  --exclude='server/dashboard/node_modules' \
  --exclude='server/logs' \
  --exclude='server/.env' \
  server/

# Upload to VPS
scp server.tar.gz root@72.61.87.54:/opt/
```

### Step 2: Initial VPS Setup (First Time Only)

```bash
# SSH into VPS
ssh root@72.61.87.54
# Password: VWJetta2014Asd))

# Extract files
cd /opt
tar -xzf server.tar.gz
cd server

# Run initial setup (installs Docker, firewall, etc.)
chmod +x setup-vps.sh
./setup-vps.sh

# This will install:
# - Docker & Docker Compose
# - Firewall (UFW)
# - Fail2ban
# - Essential packages
```

### Step 3: Configure and Start

```bash
# Still on VPS in /opt/server

# Create .env file
nano .env
```

**Paste this and fill in your values:**
```env
# Supabase
SUPABASE_URL=https://xxxxx.supabase.co
SUPABASE_SERVICE_KEY=eyJhbGc...

# Stripe
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...

# Twilio
TWILIO_ACCOUNT_SID=ACxxxxx
TWILIO_AUTH_TOKEN=xxxxx
TWILIO_PHONE_NUMBER=+1234567890

# Email
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password

# Dashboard
DASHBOARD_USERNAME=admin
DASHBOARD_PASSWORD=ChangeThisPassword123!

# Redis
REDIS_URL=redis://redis:6379

# App
APP_URL=http://72.61.87.54
NODE_ENV=production
```

**Save and exit** (Ctrl+X, Y, Enter)

```bash
# Start services
docker-compose up -d --build

# Wait 30 seconds for services to start
sleep 30

# Check status
docker-compose ps

# Test health
curl http://localhost/health
curl http://localhost/api/health
```

## ✅ Verification

### Check Services are Running
```bash
docker-compose ps
```

You should see:
- ✅ esim-api (Up)
- ✅ esim-redis (Up)
- ✅ esim-dashboard (Up)
- ✅ esim-nginx (Up)

### Test Endpoints
```bash
# Health check
curl http://72.61.87.54/health

# API health
curl http://72.61.87.54/api/health

# Dashboard (in browser)
open http://72.61.87.54/dashboard
```

### View Logs
```bash
# All logs
docker-compose logs -f

# Just API
docker-compose logs -f api

# Just errors
docker-compose logs | grep -i error
```

## 🔄 Update Deployment (After First Setup)

For future updates, it's even easier:

```bash
# From local machine
cd /Users/romanpochtman/Developer/esimmain/server

# Upload new files
rsync -avz --progress \
  --exclude 'node_modules' \
  --exclude '.env' \
  --exclude 'logs' \
  ./ root@72.61.87.54:/opt/server/

# SSH and restart
ssh root@72.61.87.54 "cd /opt/server && docker-compose up -d --build"
```

Or use the automated script:
```bash
./deploy.sh
```

## 🔧 Before It Will Work

You MUST configure these external services:

### 1. Supabase Setup (5 minutes)
1. Go to https://supabase.com
2. Create new project
3. Go to SQL Editor
4. Copy contents from `server/supabase/schema.sql`
5. Execute SQL
6. Copy Project URL and Service Key to `.env`

### 2. Stripe Setup (5 minutes)
1. Go to https://dashboard.stripe.com
2. Get API keys from Developers → API keys
3. Set up webhook:
   - URL: `http://72.61.87.54/api/payment/stripe/webhook`
   - Events: `payment_intent.succeeded`, `payment_intent.payment_failed`
4. Copy keys to `.env`

### 3. Twilio Setup (5 minutes)
1. Go to https://console.twilio.com
2. Get Account SID and Auth Token
3. Buy a phone number (or use trial)
4. Copy credentials to `.env`

### 4. Email Setup (5 minutes)

**For Gmail:**
1. Enable 2-factor authentication
2. Generate App Password:
   - Google Account → Security → App Passwords
3. Copy to `.env`

**For SendGrid:**
1. Create account at https://sendgrid.com
2. Create API key
3. Use these settings:
   ```env
   SMTP_HOST=smtp.sendgrid.net
   SMTP_PORT=587
   SMTP_USER=apikey
   SMTP_PASSWORD=SG.your_api_key
   ```

## 📊 Post-Deployment Checklist

After deployment, verify:

- [ ] All containers running: `docker-compose ps`
- [ ] Health check passes: `curl http://72.61.87.54/health`
- [ ] API responds: `curl http://72.61.87.54/api/health`
- [ ] Dashboard accessible: http://72.61.87.54/dashboard
- [ ] Can login to dashboard
- [ ] All services show "healthy" in dashboard
- [ ] Test payment endpoint
- [ ] Test OTP endpoint
- [ ] Test email endpoint
- [ ] Check Supabase for logged transactions

## 🆘 Troubleshooting

### Services won't start
```bash
# Check logs
docker-compose logs

# Rebuild everything
docker-compose down
docker-compose up -d --build --force-recreate
```

### Can't connect to database
```bash
# Verify Supabase credentials
docker-compose exec api env | grep SUPABASE

# Test connection
curl -H "apikey: YOUR_KEY" https://YOUR_PROJECT.supabase.co/rest/v1/
```

### Port already in use
```bash
# Check what's using ports
sudo lsof -i :80
sudo lsof -i :443

# Stop conflicting services
sudo systemctl stop apache2  # if Apache is running
sudo systemctl stop nginx    # if system Nginx is running
```

### Permission denied
```bash
# Make scripts executable
chmod +x *.sh

# Fix ownership
chown -R root:root /opt/server
```

## 🎯 Summary

**YES, you can compress and upload**, but you need to:
1. ✅ Exclude `node_modules` (Docker will install them)
2. ✅ Create `.env` file on VPS with your credentials
3. ✅ Run `setup-vps.sh` first time (installs Docker)
4. ✅ Configure external services (Supabase, Stripe, Twilio, Email)
5. ✅ Run `docker-compose up -d --build`

**Docker handles the rest!** It will:
- Install all Node.js dependencies
- Build the containers
- Start all services
- Set up networking
- Configure health checks

---

**Total Time**: ~30 minutes (first time), ~5 minutes (updates)

