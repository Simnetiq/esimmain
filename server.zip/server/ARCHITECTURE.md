# 🏗️ System Architecture

## 📊 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         INTERNET                                 │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                    VPS (72.61.87.54)                             │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │              NGINX (Reverse Proxy)                        │  │
│  │              Port 80/443                                  │  │
│  │  • Load Balancing                                         │  │
│  │  • SSL Termination                                        │  │
│  │  • Rate Limiting                                          │  │
│  └────────────────┬──────────────────┬───────────────────────┘  │
│                   │                  │                           │
│         ┌─────────▼──────┐  ┌───────▼────────┐                 │
│         │  API Service   │  │   Dashboard    │                 │
│         │  Port 3001     │  │   Port 3002    │                 │
│         │                │  │                │                 │
│         │ • Payments     │  │ • Monitoring   │                 │
│         │ • OTP          │  │ • Analytics    │                 │
│         │ • Emails       │  │ • Health       │                 │
│         │ • Logging      │  │ • WebSocket    │                 │
│         └────────┬───────┘  └────────────────┘                 │
│                  │                                               │
│         ┌────────▼───────┐                                      │
│         │  Redis Cache   │                                      │
│         │  Port 6379     │                                      │
│         │                │                                      │
│         │ • Rate Limit   │                                      │
│         │ • OTP Storage  │                                      │
│         │ • Sessions     │                                      │
│         └────────────────┘                                      │
└─────────────────────────────────────────────────────────────────┘
                   │
                   │ HTTPS
                   ▼
┌─────────────────────────────────────────────────────────────────┐
│                    EXTERNAL SERVICES                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │  Supabase    │  │   Stripe     │  │   Twilio     │          │
│  │  (Database)  │  │  (Payments)  │  │  (OTP/SMS)   │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
│  ┌──────────────┐  ┌──────────────┐                            │
│  │   PayPal     │  │     SMTP     │                            │
│  │  (Payments)  │  │   (Email)    │                            │
│  └──────────────┘  └──────────────┘                            │
└─────────────────────────────────────────────────────────────────┘
```

## 🔄 Request Flow

### Payment Request Flow
```
User → Nginx → API Service → Stripe/PayPal → Response
                    ↓
              Supabase (Log Transaction)
                    ↓
              Redis (Cache)
                    ↓
              Dashboard (Update Stats)
```

### OTP Request Flow
```
User → Nginx → API Service → Redis (Check Rate Limit)
                    ↓
              Generate OTP
                    ↓
              Redis (Store OTP)
                    ↓
              Twilio (Send SMS)
                    ↓
              Supabase (Log OTP)
```

### Email Request Flow
```
User → Nginx → API Service → SMTP Server
                    ↓
              Supabase (Log Email)
                    ↓
              Dashboard (Update Stats)
```

## 🗄️ Data Flow

```
┌──────────────────────────────────────────────────────────────┐
│                    DATA FLOW DIAGRAM                          │
└──────────────────────────────────────────────────────────────┘

1. PAYMENT PROCESSING
   ┌─────────┐     ┌─────────┐     ┌──────────┐     ┌──────────┐
   │  User   │────▶│   API   │────▶│  Stripe  │────▶│ Webhook  │
   └─────────┘     └────┬────┘     └──────────┘     └─────┬────┘
                        │                                   │
                        ▼                                   ▼
                   ┌─────────┐                        ┌─────────┐
                   │Supabase │◀───────────────────────│   API   │
                   │  (Log)  │                        │(Update) │
                   └─────────┘                        └─────────┘

2. OTP VERIFICATION
   ┌─────────┐     ┌─────────┐     ┌─────────┐     ┌──────────┐
   │  User   │────▶│   API   │────▶│  Redis  │────▶│  Twilio  │
   └─────────┘     └────┬────┘     │ (Store) │     └──────────┘
                        │           └─────────┘
                        ▼
                   ┌─────────┐
                   │Supabase │
                   │  (Log)  │
                   └─────────┘

3. EMAIL DELIVERY
   ┌─────────┐     ┌─────────┐     ┌─────────┐     ┌──────────┐
   │  User   │────▶│   API   │────▶│  SMTP   │────▶│Recipient │
   └─────────┘     └────┬────┘     └─────────┘     └──────────┘
                        │
                        ▼
                   ┌─────────┐
                   │Supabase │
                   │  (Log)  │
                   └─────────┘
```

## 🔐 Security Layers

```
┌─────────────────────────────────────────────────────────────┐
│                    SECURITY ARCHITECTURE                     │
└─────────────────────────────────────────────────────────────┘

Layer 1: NETWORK SECURITY
┌──────────────────────────────────────────────────────────┐
│ • UFW Firewall (Ports 22, 80, 443 only)                 │
│ • Fail2ban (Brute force protection)                     │
│ • SSH Key Authentication                                │
└──────────────────────────────────────────────────────────┘
                        ▼
Layer 2: APPLICATION SECURITY
┌──────────────────────────────────────────────────────────┐
│ • Rate Limiting (Redis-based)                           │
│ • Helmet.js (Security headers)                          │
│ • CORS Protection                                       │
│ • Input Validation (Joi)                                │
└──────────────────────────────────────────────────────────┘
                        ▼
Layer 3: AUTHENTICATION
┌──────────────────────────────────────────────────────────┐
│ • Basic Auth (Dashboard)                                │
│ • API Key Validation                                    │
│ • Webhook Signature Verification                        │
└──────────────────────────────────────────────────────────┘
                        ▼
Layer 4: DATA SECURITY
┌──────────────────────────────────────────────────────────┐
│ • Environment Variables (Secrets)                       │
│ • HTTPS/TLS Encryption                                  │
│ • Database Encryption (Supabase)                        │
└──────────────────────────────────────────────────────────┘
```

## 📊 Database Schema

```
┌─────────────────────────────────────────────────────────────┐
│                    SUPABASE TABLES                           │
└─────────────────────────────────────────────────────────────┘

TRANSACTIONS
┌──────────────┬──────────────┬──────────────────────────────┐
│ id (UUID)    │ payment_id   │ provider (stripe/paypal)     │
│ amount       │ currency     │ status (pending/completed)   │
│ metadata     │ created_at   │ updated_at                   │
└──────────────┴──────────────┴──────────────────────────────┘
         │
         ├─ Indexes: payment_id, status, created_at
         └─ Triggers: update_updated_at

EMAIL_LOGS
┌──────────────┬──────────────┬──────────────────────────────┐
│ id (UUID)    │ to_email     │ subject                      │
│ status       │ message_id   │ error                        │
│ created_at   │              │                              │
└──────────────┴──────────────┴──────────────────────────────┘
         │
         └─ Indexes: to_email, status, created_at

OTP_LOGS
┌──────────────┬──────────────┬──────────────────────────────┐
│ id (UUID)    │ phone_number │ purpose                      │
│ status       │ message_sid  │ created_at                   │
│ verified_at  │              │                              │
└──────────────┴──────────────┴──────────────────────────────┘
         │
         └─ Indexes: phone_number, created_at

HEALTH_LOGS
┌──────────────┬──────────────┬──────────────────────────────┐
│ id (UUID)    │ service      │ status                       │
│ details      │ created_at   │                              │
└──────────────┴──────────────┴──────────────────────────────┘
         │
         └─ Indexes: service, created_at

API_LOGS
┌──────────────┬──────────────┬──────────────────────────────┐
│ id (UUID)    │ endpoint     │ method                       │
│ status_code  │ response_time│ ip_address                   │
│ user_agent   │ created_at   │                              │
└──────────────┴──────────────┴──────────────────────────────┘
         │
         └─ Indexes: endpoint, created_at
```

## 🔄 Service Dependencies

```
┌─────────────────────────────────────────────────────────────┐
│                  SERVICE DEPENDENCIES                        │
└─────────────────────────────────────────────────────────────┘

NGINX
  ├─ Depends on: API Service, Dashboard
  └─ Provides: Reverse Proxy, Load Balancing

API SERVICE
  ├─ Depends on: Redis, Supabase
  ├─ Integrates: Stripe, PayPal, Twilio, SMTP
  └─ Provides: REST API, Webhooks

DASHBOARD
  ├─ Depends on: API Service, Supabase
  └─ Provides: Monitoring UI, WebSocket Updates

REDIS
  ├─ Depends on: None
  └─ Provides: Caching, Rate Limiting, OTP Storage

SUPABASE (External)
  ├─ Depends on: None
  └─ Provides: PostgreSQL Database, REST API

STRIPE (External)
  ├─ Depends on: None
  └─ Provides: Payment Processing, Webhooks

TWILIO (External)
  ├─ Depends on: None
  └─ Provides: SMS, WhatsApp Messaging

SMTP (External)
  ├─ Depends on: None
  └─ Provides: Email Delivery
```

## 📈 Scaling Strategy

```
┌─────────────────────────────────────────────────────────────┐
│                    SCALING APPROACH                          │
└─────────────────────────────────────────────────────────────┘

HORIZONTAL SCALING
┌──────────────────────────────────────────────────────────┐
│                                                          │
│  Load Balancer (Nginx)                                  │
│         │                                                │
│    ┌────┴────┬────────┬────────┐                       │
│    ▼         ▼        ▼        ▼                       │
│  API-1    API-2    API-3    API-N                      │
│    │         │        │        │                       │
│    └────┬────┴────────┴────────┘                       │
│         ▼                                               │
│    Shared Redis                                         │
│         ▼                                               │
│    Supabase (Auto-scales)                              │
│                                                          │
└──────────────────────────────────────────────────────────┘

VERTICAL SCALING
┌──────────────────────────────────────────────────────────┐
│ • Increase VPS resources (CPU, RAM)                     │
│ • Optimize Redis memory                                 │
│ • Database connection pooling                           │
│ • Enable caching strategies                             │
└──────────────────────────────────────────────────────────┘

PERFORMANCE OPTIMIZATION
┌──────────────────────────────────────────────────────────┐
│ • Redis caching for frequent queries                    │
│ • Database query optimization                           │
│ • CDN for static assets                                 │
│ • Gzip compression                                      │
│ • Connection pooling                                    │
└──────────────────────────────────────────────────────────┘
```

## 🔍 Monitoring Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                  MONITORING STACK                            │
└─────────────────────────────────────────────────────────────┘

REAL-TIME MONITORING
┌──────────────────────────────────────────────────────────┐
│                    Dashboard                             │
│  ┌────────────────────────────────────────────────────┐ │
│  │ • System Health (API, Redis, Supabase, Docker)    │ │
│  │ • Transaction Stats (Total, Today, Revenue)       │ │
│  │ • Email Delivery (Sent, Failed)                   │ │
│  │ • Docker Containers (Status, Uptime)              │ │
│  │ • Real-time Updates (WebSocket)                   │ │
│  └────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────┘

LOGGING
┌──────────────────────────────────────────────────────────┐
│ Winston Logger                                           │
│  ├─ Combined Logs (All events)                          │
│  ├─ Error Logs (Errors only)                            │
│  ├─ Daily Rotation (14 days retention)                  │
│  └─ JSON Format (Structured logging)                    │
└──────────────────────────────────────────────────────────┘

HEALTH CHECKS
┌──────────────────────────────────────────────────────────┐
│ Docker Health Checks                                     │
│  ├─ API Service (Every 30s)                             │
│  ├─ Dashboard (Every 30s)                               │
│  └─ Redis (Ping check)                                  │
└──────────────────────────────────────────────────────────┘

EXTERNAL MONITORING (Recommended)
┌──────────────────────────────────────────────────────────┐
│ • UptimeRobot (Uptime monitoring)                       │
│ • Sentry (Error tracking)                               │
│ • Datadog (Infrastructure monitoring)                   │
│ • CloudWatch (AWS monitoring)                           │
└──────────────────────────────────────────────────────────┘
```

## 🔄 Deployment Pipeline

```
┌─────────────────────────────────────────────────────────────┐
│                  DEPLOYMENT FLOW                             │
└─────────────────────────────────────────────────────────────┘

LOCAL DEVELOPMENT
    │
    ├─ Code Changes
    ├─ Local Testing
    └─ Git Commit
         │
         ▼
VERSION CONTROL (Git)
    │
    ├─ Push to Repository
    └─ Trigger CI/CD (Optional)
         │
         ▼
VPS DEPLOYMENT
    │
    ├─ SSH into VPS
    ├─ Pull Latest Code
    ├─ Update .env
    ├─ docker-compose down
    ├─ docker-compose up -d --build
    └─ Verify Deployment
         │
         ▼
HEALTH CHECKS
    │
    ├─ Check Service Status
    ├─ Run API Tests
    ├─ Monitor Dashboard
    └─ Review Logs
         │
         ▼
PRODUCTION READY ✅
```

## 📦 Container Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                  DOCKER CONTAINERS                           │
└─────────────────────────────────────────────────────────────┘

esim-nginx (Nginx)
  ├─ Image: nginx:alpine
  ├─ Ports: 80:80, 443:443
  ├─ Volumes: nginx.conf, SSL certs, logs
  └─ Network: esim-network

esim-api (API Service)
  ├─ Image: node:20-alpine
  ├─ Port: 3001:3001
  ├─ Volumes: logs
  ├─ Depends: redis
  └─ Network: esim-network

esim-dashboard (Dashboard)
  ├─ Image: node:20-alpine
  ├─ Port: 3002:3002
  ├─ Depends: api, redis
  └─ Network: esim-network

esim-redis (Redis)
  ├─ Image: redis:7-alpine
  ├─ Port: 6379:6379
  ├─ Volumes: redis-data (persistent)
  └─ Network: esim-network

NETWORK: esim-network (Bridge)
VOLUMES: redis-data (Persistent storage)
```

---

This architecture is designed for:
- ✅ **Scalability**: Easy to add more API instances
- ✅ **Reliability**: Health checks and monitoring
- ✅ **Security**: Multiple security layers
- ✅ **Maintainability**: Clear separation of concerns
- ✅ **Performance**: Caching and optimization
- ✅ **Observability**: Comprehensive logging and monitoring

